from threading import Lock
from typing import Any


class ComicStore:
    def __init__(self):
        self._data: dict[str, dict[str, Any]] = {}
        self._lock = Lock()

    def put(self, comic_id: str, comic: dict[str, Any]) -> None:
        with self._lock:
            self._data[comic_id] = comic

    def get(self, comic_id: str) -> dict[str, Any] | None:
        with self._lock:
            return self._data.get(comic_id)


store = ComicStore()
