import json
import uuid
from pathlib import Path

from fastapi import APIRouter, Form, HTTPException, Request
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.templating import Jinja2Templates

from app.models import PromptRequest
from app.services.exporters import save_pdf
from app.services.gemini_flash import generate_outline
from app.services.gemini_pro import generate_story
from app.services.image_generator import generate_image
from app.services.layout_builder import build_comic_layout
from app.store import store

BASE_DIR = Path(__file__).resolve().parent.parent
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))

router = APIRouter()


def _generate_comic(
    story_prompt: str,
    character_name: str,
    setting: str,
    tone: str,
    art_style: str,
):
    outline = generate_outline(
        story_prompt,
        character_name,
        setting,
        tone,
        art_style,
    )

    story = generate_story(
        outline,
        story_prompt,
        character_name,
        setting,
        tone,
        art_style,
    )

    image_paths = [
        generate_image(panel["image_prompt"], panel["panel_number"])
        for panel in story
    ]

    layout = build_comic_layout(story, image_paths)
    pdf_path = save_pdf(layout)

    comic_id = str(uuid.uuid4())
    store.put(
        comic_id,
        {
            "comic_id": comic_id,
            "story_prompt": story_prompt,
            "character_name": character_name,
            "setting": setting,
            "tone": tone,
            "art_style": art_style,
            "layout": layout,
            "pdf_path": pdf_path,
        },
    )

    return comic_id, layout, pdf_path


@router.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="index.html",
        context={},
    )


@router.post("/generate", response_class=HTMLResponse)
def generate(
    request: Request,
    story_prompt: str = Form(...),
    character_name: str = Form(...),
    setting: str = Form(...),
    tone: str = Form(...),
    art_style: str = Form(...),
):
    try:
        comic_id, layout, pdf_path = _generate_comic(
            story_prompt,
            character_name,
            setting,
            tone,
            art_style,
        )

        return templates.TemplateResponse(
            request=request,
            name="comic_preview.html",
            context={
                "layout": layout,
                "comic_id": comic_id,
                "pdf_path": pdf_path,
            },
        )
    except Exception as exc:
        return templates.TemplateResponse(
            request=request,
            name="error.html",
            context={"error": str(exc)},
            status_code=500,
        )


@router.post("/generate-comic/json")
def generate_json(payload: PromptRequest):
    try:
        comic_id, layout, pdf_path = _generate_comic(
            payload.story_prompt,
            payload.character_name,
            payload.setting,
            payload.tone,
            payload.art_style,
        )

        return {
            "comic_id": comic_id,
            "layout": layout,
            "pdf_path": pdf_path,
        }
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.post("/export-success", response_class=HTMLResponse)
def export_success(request: Request, comic_id: str = Form(...)):
    comic = store.get(comic_id)

    if not comic:
        return templates.TemplateResponse(
            request=request,
            name="error.html",
            context={"error": "Comic session expired or was not found."},
            status_code=404,
        )

    return templates.TemplateResponse(
        request=request,
        name="export_success.html",
        context={
            "comic_id": comic_id,
            "pdf_path": comic["pdf_path"],
        },
    )


@router.get("/download/{comic_id}")
def download_pdf(comic_id: str):
    comic = store.get(comic_id)

    if not comic:
        raise HTTPException(status_code=404, detail="Comic not found.")

    relative = comic["pdf_path"].replace("/static/", "", 1)
    pdf_file = BASE_DIR / "static" / relative

    if not pdf_file.exists():
        raise HTTPException(status_code=404, detail="PDF file not found.")

    return FileResponse(
        path=pdf_file,
        media_type="application/pdf",
        filename=pdf_file.name,
    )


@router.get("/test-image", response_class=HTMLResponse)
def test_image(request: Request, prompt: str = "a cute fox in an enchanted forest, comic art"):
    try:
        image_path = generate_image(prompt, 999)
        return templates.TemplateResponse(
            request=request,
            name="test_image.html",
            context={"image_path": image_path, "prompt": prompt},
        )
    except Exception as exc:
        return templates.TemplateResponse(
            request=request,
            name="error.html",
            context={"error": str(exc)},
            status_code=500,
        )
