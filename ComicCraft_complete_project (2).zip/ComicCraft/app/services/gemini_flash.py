import json
import re

from app.config import GEMINI_FLASH_MODEL
from app.services.gemini_client import get_client


def _extract_json(text: str):
    text = text.strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?", "", text, flags=re.I).strip()
        text = re.sub(r"```$", "", text).strip()

    match = re.search(r"\[.*\]", text, flags=re.S)
    if not match:
        raise ValueError("Gemini did not return a JSON panel outline.")

    return json.loads(match.group(0))


def generate_outline(
    story_prompt: str,
    character_name: str,
    setting: str,
    tone: str,
    art_style: str,
) -> list[dict]:
    prompt = f"""
Create a five-panel comic outline.

User story idea: {story_prompt}
Main character: {character_name}
Setting: {setting}
Tone: {tone}
Art style: {art_style}

Return ONLY valid JSON. Return exactly an array with five objects.
Each object must contain:
- panel_number: integer 1-5
- title: short panel title
- scene_description: 1-2 sentence visual scene description
- image_prompt: detailed image-generation prompt

The same main character must remain visually consistent across panels.
Do not put dialogue in image_prompt. Do not use markdown.
""".strip()

    client = get_client()
    response = client.models.generate_content(
        model=GEMINI_FLASH_MODEL,
        contents=prompt,
    )

    data = _extract_json(response.text or "")

    if not isinstance(data, list) or len(data) != 5:
        raise ValueError("Gemini outline must contain exactly five panels.")

    normalized = []
    for i, panel in enumerate(data, start=1):
        normalized.append(
            {
                "panel_number": i,
                "title": str(panel.get("title", f"Panel {i}")),
                "scene_description": str(panel.get("scene_description", "")),
                "image_prompt": str(panel.get("image_prompt", "")),
            }
        )

    return normalized
