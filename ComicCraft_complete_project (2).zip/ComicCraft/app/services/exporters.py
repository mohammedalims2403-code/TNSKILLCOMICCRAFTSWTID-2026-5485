from pathlib import Path
from datetime import datetime

from fpdf import FPDF

from app.config import EXPORTS_DIR


def save_pdf(layout: list[dict]) -> str:
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_path = EXPORTS_DIR / f"comic_{timestamp}.pdf"

    pdf = FPDF()
    pdf.set_auto_page_break(auto=True, margin=16)

    for panel in layout:
        pdf.add_page()

        pdf.set_font("Helvetica", "B", 18)
        pdf.multi_cell(0, 10, f'Panel {panel["panel_number"]}: {panel["title"]}')
        pdf.ln(3)

        image_path = Path(panel["image_path"])
        if not image_path.is_absolute():
            image_path = Path(__file__).resolve().parents[2] / panel["image_path"].lstrip("/")

        if image_path.exists():
            pdf.image(str(image_path), x=25, w=160)
            pdf.ln(5)

        pdf.set_font("Helvetica", "I", 10)
        pdf.multi_cell(0, 6, panel.get("scene_description", ""))
        pdf.ln(3)

        pdf.set_font("Helvetica", "B", 11)
        pdf.multi_cell(0, 6, "Caption")
        pdf.set_font("Helvetica", "", 11)
        pdf.multi_cell(0, 6, panel.get("caption", ""))
        pdf.ln(2)

        pdf.set_font("Helvetica", "B", 11)
        pdf.multi_cell(0, 6, "Narration")
        pdf.set_font("Helvetica", "", 11)
        pdf.multi_cell(0, 6, panel.get("narration", ""))
        pdf.ln(2)

        pdf.set_font("Helvetica", "B", 11)
        pdf.multi_cell(0, 6, "Dialogue")
        pdf.set_font("Helvetica", "", 11)
        pdf.multi_cell(0, 6, panel.get("dialogue", ""))

    pdf.output(str(output_path))

    return f"/static/exports/{output_path.name}"
