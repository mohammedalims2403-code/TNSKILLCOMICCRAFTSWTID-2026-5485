def build_comic_layout(story_panels: list[dict], image_paths: list[str]) -> list[dict]:
    if len(story_panels) != len(image_paths):
        raise ValueError("Every story panel must have exactly one image.")

    layout = []

    for panel, image_path in zip(story_panels, image_paths):
        layout.append(
            {
                **panel,
                "image_path": image_path,
            }
        )

    return layout
