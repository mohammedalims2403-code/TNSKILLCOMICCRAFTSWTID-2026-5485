from app.config import GEMINI_PRO_MODEL
from app.services.gemini_client import get_client


def generate_story(
    outline: list[dict],
    story_prompt: str,
    character_name: str,
    setting: str,
    tone: str,
    art_style: str,
) -> list[dict]:
    outline_text = "\n".join(
        f"""Panel {p["panel_number"]}: {p["title"]}
Scene: {p["scene_description"]}
Image prompt: {p["image_prompt"]}"""
        for p in outline
    )

    prompt = f"""
Expand the following five-panel outline into a polished comic script.

Story idea: {story_prompt}
Main character: {character_name}
Setting: {setting}
Tone: {tone}
Art style: {art_style}

OUTLINE:
{outline_text}

Return ONLY valid JSON as an array of five objects.
Each object must contain:
- panel_number
- title
- scene_description
- caption
- narration
- dialogue

Requirements:
- Keep the story coherent from panel 1 through panel 5.
- Keep the character's name and personality consistent.
- Dialogue should be concise enough to fit in a comic panel.
- Narration should be vivid but concise.
- Do not use markdown or code fences.
""".strip()

    client = get_client()
    response = client.models.generate_content(
        model=GEMINI_PRO_MODEL,
        contents=prompt,
    )

    import json
    import re

    text = (response.text or "").strip()
    text = re.sub(r"^```(?:json)?", "", text, flags=re.I).strip()
    text = re.sub(r"```$", "", text).strip()

    match = re.search(r"\[.*\]", text, flags=re.S)
    if not match:
        raise ValueError("Gemini did not return a JSON comic script.")

    data = json.loads(match.group(0))

    if not isinstance(data, list) or len(data) != 5:
        raise ValueError("Gemini story must contain exactly five panels.")

    result = []
    for i, panel in enumerate(data, start=1):
        result.append(
            {
                "panel_number": i,
                "title": str(panel.get("title", outline[i - 1]["title"])),
                "scene_description": str(
                    panel.get(
                        "scene_description",
                        outline[i - 1]["scene_description"],
                    )
                ),
                "caption": str(panel.get("caption", "")),
                "narration": str(panel.get("narration", "")),
                "dialogue": str(panel.get("dialogue", "")),
                "image_prompt": outline[i - 1]["image_prompt"],
            }
        )

    return result
