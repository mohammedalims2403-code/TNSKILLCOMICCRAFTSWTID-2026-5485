from google import genai

from app.config import GEMINI_API_KEY


def get_client():
    if not GEMINI_API_KEY:
        raise RuntimeError(
            "GEMINI_API_KEY is missing. Add it to the .env file."
        )
    return genai.Client(api_key=GEMINI_API_KEY)
