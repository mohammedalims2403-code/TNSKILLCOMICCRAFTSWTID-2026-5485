import re
from pathlib import Path

from PIL import Image

from app.config import (
    HF_API_KEY,
    HF_IMAGE_MODEL,
    IMAGE_BACKEND,
    LOCAL_DIFFUSION_MODEL,
    PANELS_DIR,
)


def _safe_name(text: str) -> str:
    value = re.sub(r"[^a-zA-Z0-9_-]+", "_", text).strip("_")
    return value[:60] or "panel"


def _save_hf_image(prompt: str, filename: str) -> str:
    if not HF_API_KEY:
        raise RuntimeError(
            "HF_API_KEY is missing. Add it to .env or use IMAGE_BACKEND=local."
        )

    from huggingface_hub import InferenceClient

    client = InferenceClient(
        provider="hf-inference",
        api_key=HF_API_KEY,
    )

    image = client.text_to_image(
        prompt,
        model=HF_IMAGE_MODEL,
    )

    path = PANELS_DIR / filename
    image.save(path)
    return f"/static/panels/{filename}"


def _save_local_image(prompt: str, filename: str) -> str:
    import torch
    from diffusers import StableDiffusionPipeline

    dtype = torch.float16 if torch.cuda.is_available() else torch.float32
    pipe = StableDiffusionPipeline.from_pretrained(
        LOCAL_DIFFUSION_MODEL,
        torch_dtype=dtype,
        use_safetensors=True,
    )

    device = "cuda" if torch.cuda.is_available() else "cpu"
    pipe = pipe.to(device)

    if device == "cpu":
        pipe.enable_attention_slicing()

    image = pipe(
        prompt,
        num_inference_steps=20,
        guidance_scale=7.0,
        height=512,
        width=512,
    ).images[0]

    path = PANELS_DIR / filename
    image.save(path)
    return f"/static/panels/{filename}"


def generate_image(image_prompt: str, panel_number: int) -> str:
    prompt = (
        "comic panel illustration, consistent character design, "
        "clear composition, expressive faces, cinematic lighting, "
        f"{image_prompt}"
    )

    filename = f"panel_{panel_number}_{_safe_name(image_prompt[:40])}.png"

    if IMAGE_BACKEND == "local":
        return _save_local_image(prompt, filename)

    return _save_hf_image(prompt, filename)
