import os
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent.parent
STATIC_DIR = BASE_DIR / "static"
PANELS_DIR = STATIC_DIR / "panels"
EXPORTS_DIR = STATIC_DIR / "exports"

PANELS_DIR.mkdir(parents=True, exist_ok=True)
EXPORTS_DIR.mkdir(parents=True, exist_ok=True)

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "").strip()
GEMINI_FLASH_MODEL = os.getenv("GEMINI_FLASH_MODEL", "gemini-3.8-flash").strip()
GEMINI_PRO_MODEL = os.getenv("GEMINI_PRO_MODEL", "gemini-3.1-pro-preview").strip()

HF_API_KEY = os.getenv("HF_API_KEY", "").strip()
HF_IMAGE_MODEL = os.getenv(
    "HF_IMAGE_MODEL",
    "stable-diffusion-v1-5/stable-diffusion-v1-5",
).strip()

IMAGE_BACKEND = os.getenv("IMAGE_BACKEND", "huggingface").strip().lower()
LOCAL_DIFFUSION_MODEL = os.getenv(
    "LOCAL_DIFFUSION_MODEL",
    "stable-diffusion-v1-5/stable-diffusion-v1-5",
).strip()
