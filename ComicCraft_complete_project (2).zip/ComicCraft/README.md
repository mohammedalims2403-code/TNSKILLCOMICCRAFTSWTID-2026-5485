# ComicCraft — AI Comic Story Creator

ComicCraft follows the supplied documentation's architecture:

HTML/CSS/Jinja2 frontend
        ↓
FastAPI backend
        ↓
Gemini outline generation
        ↓
Gemini story/dialogue generation
        ↓
Hugging Face image generation / optional local Diffusers
        ↓
Comic layout
        ↓
FPDF PDF export

## Important update from the supplied documentation

The documentation uses the older `google-generativeai` SDK and Gemini 1.5 Flash/Pro.
This implementation uses Google's current `google-genai` SDK and configurable current
Gemini model IDs. The defaults are controlled by `.env`.

The documentation also describes local Stable Diffusion through Diffusers. Local
Stable Diffusion can require significant disk/RAM/VRAM and is inconvenient for a
first Windows setup. Therefore the default image backend uses Hugging Face's
InferenceClient. You can switch to local Diffusers later with `IMAGE_BACKEND=local`
and install `requirements-local-image.txt`.

## Folder structure

```text
ComicCraft/
├── app/
│   ├── __init__.py
│   ├── main.py
│   ├── config.py
│   ├── models.py
│   ├── routes.py
│   ├── store.py
│   └── services/
│       ├── __init__.py
│       ├── gemini_client.py
│       ├── gemini_flash.py
│       ├── gemini_pro.py
│       ├── image_generator.py
│       ├── layout_builder.py
│       └── exporters.py
├── templates/
│   ├── index.html
│   ├── comic_preview.html
│   ├── export_success.html
│   ├── test_image.html
│   └── error.html
├── static/
│   ├── css/style.css
│   ├── panels/.gitkeep
│   └── exports/.gitkeep
├── .env.example
├── .gitignore
├── requirements.txt
├── requirements-local-image.txt
└── README.md
```

## Windows setup

Open the project in VS Code.

Create the environment:

```powershell
python -m venv .venv
```

Activate it:

```powershell
.\.venv\Scripts\Activate.ps1
```

Install the main dependencies:

```powershell
pip install -r requirements.txt
```

Create `.env` from `.env.example`.

Add:

```text
GEMINI_API_KEY=your_key
HF_API_KEY=your_huggingface_token
```

Start the server:

```powershell
uvicorn app.main:app --reload
```

Open:

```text
http://127.0.0.1:8000
```

FastAPI docs:

```text
http://127.0.0.1:8000/docs
```

## JSON API

POST `/generate-comic/json`:

```json
{
  "story_prompt": "A brave fox exploring an enchanted forest",
  "character_name": "Luna",
  "setting": "Forest",
  "tone": "Adventurous",
  "art_style": "Comic Book"
}
```

## Image backend

Default:

```text
IMAGE_BACKEND=huggingface
```

For local Diffusers:

```text
IMAGE_BACKEND=local
```

Then install:

```powershell
pip install -r requirements-local-image.txt
```

Local Stable Diffusion is much heavier than the default API approach.

## Core routes

- `GET /` — homepage
- `POST /generate` — browser form generation
- `POST /generate-comic/json` — JSON API generation
- `GET /test-image` — image generation test
- `GET /download/{comic_id}` — PDF download
- `POST /export-success` — export confirmation
- `GET /health` — health check
